using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)
$templatePath = $Request.Body.templatePath
$format = $Request.Body.format

try {
    $size = (Invoke-WebRequest -Uri $templatePath -Method Head).Headers.'Content-Length'
    if ([convert]::ToInt32($size, 10) -le 100000000) {
        $template = (Invoke-WebRequest -Uri $templatePath -UseBasicParsing).Content
        if($format -eq 'json' -and $templatePath -like "*json") { $templateData = $template |ConvertFrom-Json} `
        elseif($format -eq 'csv' -and $templatePath -like "*csv") { $templateData = $template |ConvertFrom-Csv} `
        else {$result = @()}

        if($templateData.count -gt 0){
            $row = $templateData[0]
            $names = $row.PSObject.Properties.Name

            #$result = $names|%{[ordered]@{
            #    Field = $_
            #    Values = @(($templateData|? $_ -ne ''|? $_ -ne $null).$_ | sort -Unique)
            #}}|? Values

            $temparray = @()
            foreach ($name in $names) {
            if ($name -notmatch 'TimeGenerated') {
                if ($templateData.$name -ne '' -and $templateData.$name -ne $null -and $name.Length -le 45 -and $name -notlike "_*") {
                $temparray += @{Field = $name; Values = $templateData.$name}
                }  
            }
            }
            $result = $temparray | Sort-Object -Property Field
        }



    } else {
        Write-Output "File too big"
        $result =  @{Error="File too big"}
    }
    # Associate values to output bindings by calling 'Push-OutputBinding'.
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::OK
        Body = $result
    })
}
catch {
    Write-Output "Detailed error:"
    Write-Output $_
}

